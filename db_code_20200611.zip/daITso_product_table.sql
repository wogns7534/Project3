use daitso;
CREATE TABLE `product_classification` (
    `classification_no` INT NOT NULL AUTO_INCREMENT,
    `classification_name` VARCHAR(20) NOT NULL UNIQUE,
    PRIMARY KEY (classification_no)
);

CREATE TABLE `seller` (
	`seller_id`	VARCHAR(15)	NOT NULL,
	`seller_passwd`	VARCHAR(20)	NOT NULL,
	`seller_name`	VARCHAR(5)	NOT NULL,
	`seller_zipcode`	INT	 NOT NULL,
	`seller_address`	VARCHAR(30)	NOT NULL,
	`seller_mobile`	VARCHAR(15)	NOT NULL,
	`seller_email`	VARCHAR(30)	NOT NULL,
	`company_number`	VARCHAR(20)	NOT NULL,
	`company_name`	VARCHAR(15)	NOT NULL,
    PRIMARY KEY (seller_id)
);

CREATE TABLE `customer` (
	`customer_id`	VARCHAR(15)	NOT NULL,
	`customer_passwd`	VARCHAR(20)	NOT NULL,
	`customer_name`	VARCHAR(5) NOT NULL,
	`customer_address`	VARCHAR(50)	NOT NULL,
	`customer_zipcode`	INT	NOT NULL,
	`customer_phone`	VARCHAR(15) NOT NULL,
	`customer_email`	VARCHAR(30)	NOT NULL,
    PRIMARY KEY (customer_id)
);

CREATE TABLE `product` (
    `product_no` INT NOT NULL AUTO_INCREMENT,
    `product_name` VARCHAR(50) NOT NULL,
    `detail_description` VARCHAR(300) NOT NULL,
    `product_price` INT NOT NULL,
    `product_quantity` INT NOT NULL DEFAULT 999,
    `purchase_count` INT NOT NULL DEFAULT 0,
    `product_sale` INT NOT NULL DEFAULT 0,
    `monoter_inch` INT NULL DEFAULT 0,
    `product_img` VARCHAR(100) NULL,
    `classification_no` INT NOT NULL,
    `seller_id` VARCHAR(15)	NOT NULL DEFAULT 'example_seller',
    PRIMARY KEY (product_no),
    FOREIGN KEY (classification_no)
        REFERENCES product_classification (classification_no),
	FOREIGN KEY (seller_id)
        REFERENCES seller (seller_id)
);

CREATE TABLE `review` (
    `customer_name` VARCHAR(10) NOT NULL,
    `product_no` INT NOT NULL,
    `review_comment` VARCHAR(100) NOT NULL,
    `review_time` TIMESTAMP NOT NULL DEFAULT NOW(),
    `review_grade` INT NULL,
    PRIMARY KEY (customer_name, product_no),
    FOREIGN KEY (product_no)
        REFERENCES product (product_no)
);
        





