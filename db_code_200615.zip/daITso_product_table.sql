use daitso;
CREATE TABLE `bdiv` (
	`bdiv_no`	INT	NOT NULL,
	`bdiv_name`	VARCHAR(20)	NULL,
    primary KEY (bdiv_no)
);

CREATE TABLE `sdiv` (
	`sdiv_no`	INT	NOT NULL,
	`sdiv_name`	VARCHAR(20)	NULL,
    primary key (sdiv_no)
);


CREATE TABLE `seller` (
    `seller_id` VARCHAR(15) NOT NULL,
    `seller_passwd` VARCHAR(20) NOT NULL,
    `seller_name` VARCHAR(5) NOT NULL,
    `seller_zipcode` VARCHAR(10) NOT NULL,
    `seller_address` VARCHAR(30) NOT NULL,
    `seller_mobile` VARCHAR(15) NOT NULL,
    `seller_email` VARCHAR(30) NOT NULL,
    `company_number` VARCHAR(20) NOT NULL,
    `company_name` VARCHAR(15) NOT NULL,
    PRIMARY KEY (seller_id)
);

CREATE TABLE `customer` (
    `customer_id` VARCHAR(15) NOT NULL,
    `customer_passwd` VARCHAR(20) NOT NULL,
    `customer_name` VARCHAR(5) NOT NULL,
    `customer_address` VARCHAR(50) NOT NULL,
    `customer_zipcode` VARCHAR(10) NOT NULL,
    `customer_phone` VARCHAR(15) NOT NULL,
    `customer_email` VARCHAR(30) NOT NULL,
    `customer_moeny` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (customer_id)
);

CREATE TABLE `product` (
    `product_no` INT NOT NULL AUTO_INCREMENT,
    `product_name` VARCHAR(50) NOT NULL,
    `detail_description` VARCHAR(300) NOT NULL,
    `product_price` INT NOT NULL,
    `product_quantity` INT NOT NULL DEFAULT 999,
    `purchase_count` INT NOT NULL DEFAULT 0,
    `product_sale` INT NOT NULL DEFAULT 0,
    `registration_time` TIMESTAMP NOT NULL DEFAULT NOW(),
    `monitor_inch` INT NOT NULL DEFAULT 0,
    `product_img` VARCHAR(100) NOT NULL,
    `product_thumb_img` VARCHAR(100) NOT NULL,
    `product_detail_img` VARCHAR(100) NOT NULL,
    `bdiv_no` INT NOT NULL,
    `sdiv_no` INT NOT NULL,
    `seller_id` VARCHAR(15) NOT NULL DEFAULT 'example_seller',
    PRIMARY KEY (product_no),
    FOREIGN KEY (bdiv_no)
        REFERENCES bdiv (bdiv_no),
	FOREIGN KEY (sdiv_no)
        REFERENCES sdiv (sdiv_no),
    FOREIGN KEY (seller_id)
        REFERENCES seller (seller_id)
);

CREATE TABLE `review` (
    `customer_name` VARCHAR(10) NOT NULL,
    `product_no` INT NOT NULL,
    `review_comment` VARCHAR(100) NOT NULL,
    `review_time` TIMESTAMP NOT NULL DEFAULT NOW(),
    `review_grade` INT NOT NULL DEFAULT 0,
    PRIMARY KEY (customer_name , product_no),
    FOREIGN KEY (product_no)
        REFERENCES product (product_no)
);
        
CREATE TABLE `transaction` (
	`product_no`	INT	NOT NULL,
	`customer_id`	VARCHAR(15)	NOT NULL,
	`transaction_time`	TIMESTAMP NOT NULL DEFAULT NOW(),
    `transaction_quantity` INT NOT NULL DEFAULT 1,
    `order_amount` INT NOT NULL DEFAULT 0,
    `delivery_memo` VARCHAR(30) NULL,
    FOREIGN KEY (product_no)
		REFERENCES product (product_no)
        ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (customer_id)
		REFERENCES customer (customer_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);

CREATE TABLE `shoppingcart` (
	`product_no`	INT	NOT NULL,
	`customer_id`	VARCHAR(15)	NOT NULL,
    `shoppingcart_quantity` INT NOT NULL DEFAULT 1,
    `order_amount` INT NOT NULL DEFAULT 0,
    FOREIGN KEY (product_no)
		REFERENCES product (product_no)
        ON UPDATE CASCADE ON DELETE CASCADE,
	FOREIGN KEY (customer_id)
		REFERENCES customer (customer_id)
        ON UPDATE CASCADE ON DELETE CASCADE
);



