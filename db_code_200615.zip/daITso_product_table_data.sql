use daitso;
insert into bdiv (bdiv_no, bdiv_name)
values ('1', 'DAITSO 조립PC'),
		('2', 'WINDOWS10 탑재PC'),
        ('3', '본체 + 모니터 패키지'),
        ('4', '컴퓨터 주요부품'),
        ('5', '키보드 ㆍ 마우스 Wㆍ 주변기기'),
        ('6', '모니터 ㆍ 악세서리'),
        ('7', '게이밍 의자 ㆍ 책상'),
        ('8', '프린터 ㆍ 복합기 ㆍ 스캐너'),
        ('9', '음향 ㆍ 방송용 장비'),
        ('10', '네트워크 ㆍ 공유기');
insert into sdiv (sdiv_no, sdiv_name)
values ('11', 'DAITSO 조립PC'),
		('21', 'WINDOWS10 탑재PC'),
        ('31', '본체 + 모니터 패키지'),
        ('41','CPU'), ('42','메인보드'), ('43','메모리'), ('44','그래픽카드'), ('45','SSD'), ('46','하드디스크'),('47','케이스'),('48','파워서플라이'),('49','공/수냉 쿨러'),
        ('51','키보드'),('52','마우스'),('53','키보드 + 마우스 세트'),('54','외장형 저장장치'),
        ('61','모니터'),
		('71','게이밍 의자 ㆍ 책상'),
        ('81','레이저/잉크젯 프린터'),('82','복합기'),('83','스캐너'),
        ('91','스피커'),('92','마이크'),('93','헤드셋 ㆍ 이어폰'),('94','사운드카드'),
		('101','공유기'),('102','랜 카드'),('103','랜 케이블'),('104','스위칭 허브');

insert into customer (
	customer_id,
    customer_passwd,
    customer_name,
    customer_address,
    customer_zipcode,
    customer_phone,
    customer_email)
values ('admin',
	'1234',
    '관리자',
    '서울시 노원구',
    '00000',
    '000-0000-0000',
    'admin@admin.com');
    
insert into seller (
	seller_id,
    seller_passwd,
    seller_name,
    seller_address,
    seller_zipcode,
    seller_mobile,
    seller_email,
    company_number,
    company_name)
values ('example_seller',
	'1234',
    '예시판매자',
    '서울시 노원구',
    '00000',
    '111-1111-1111',
    'seller@seller.com',
    '000-00-000000',
    '(주)daitso');
    
