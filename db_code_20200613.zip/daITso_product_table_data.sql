use daitso;
insert into product_classification (classification_name)
values ('CPU'), ('메인보드'), ('메모리'), ('그래픽카드'), ('SSD'), ('하드디스크'),('케이스'),
	('파워서플라이'),('공/수냉 쿨러'),('키보드'),('마우스'),('키보드 + 마우스 세트'),('외장형 저장장치'),('모니터'),
    ('제닉스'),('ABKO HACKER'),('GEEKSTAR'),('기타브랜드'),('제닉스 게이밍 책상 ㆍ 스툴'),('레이저/잉크젯 프린터'),
    ('복합기'),('스캐너'),('스피커'),('마이크'),('헤드셋 ㆍ 이어폰'),('사운드카드'),
    ('공유기'),('랜 카드'),('랜 케이블'),('스위칭 허브');

insert into customer (
	customer_id,
    customer_passwd,
    customer_name,
    customer_address,
    customer_zipcode,
    customer_phone,
    customer_email)
values ('admin',
	'1234',
    '관리자',
    '서울시 노원구',
    '00000',
    '000-0000-0000',
    'admin@admin.com');
    
insert into seller (
	seller_id,
    seller_passwd,
    seller_name,
    seller_address,
    seller_zipcode,
    seller_mobile,
    seller_email,
    company_number,
    company_name)
values ('example_seller',
	'1234',
    '예시판매자',
    '서울시 노원구',
    '00000',
    '111-1111-1111',
    'seller@seller.com',
    '000-00-000000',
    '(주)daitso');
    
insert into product (
    product_name,
    detail_description,
    product_price,
    product_quantity,
    purchase_count,
    product_sale,
    classification_no)
values ('AMD 라이젠 5 3500X (마티스) (멀티팩)',
    'CPU / 브랜드 분류 : AMD / 소켓 구분 : AMD(소켓AM4) / 코어 형태 : 헥사(6)코어 / 동작 속도 : 3.6GHz / 설계전력 : 65W / 쓰레드 형태 : 쓰레드 6개 / 패키지 형태 : 멀티팩 / L3 캐시 메모리 : 32MB / 제조 공정 : 7nm / GPU 모델명 : 상세내용참조 /',
    '184700',
    '999',
    '0',
    '10',
    '1');
    
insert into product (
    product_name,
    detail_description,
    product_price,
    product_quantity,
    purchase_count,
    product_sale,
    classification_no)
values ('AMD 라이젠 5 3600 마티스(정품)',
    'CPU / 제조회사 : AMD / 소켓 구분 : AMD(소켓AM4) / 브랜드 분류 : AMD(라이젠 5) / 코어 형태 : 헥사(6) 코어 / 동작 속도 : 3.6 GHz / 설계전력 : 65W / 쓰레드 형태 : 쓰레드 12개 / 제조 공정 : 7nm / L3 캐시 메모리 : 32MB / GPU 모델명 : 상세내용참조 /',
    '227200',
    '999',
    '0',
    '0',
    '1');
    
insert into product (
    product_name,
    detail_description,
    product_price,
    product_quantity,
    purchase_count,
    product_sale,
    classification_no)
values ('인텔 코어i5-10세대 10400 (코멧레이크S) (정품)',
    '인텔 / 제조회사 : 인텔 / 소켓 구분 : 인텔(소켓1200) / 코어 형태 : 헥사(6)코어 / 동작 속도 : 2.9GHz / 쓰레드 형태 : 쓰레드 12개 / 설계전력 : 65W / 제조 공정 : 14nm / GPU 모델명 : 인텔 UHD 630 /',
    '228700',
    '999',
    '0',
    '0',
    '1');
    
insert into product (
    product_name,
    detail_description,
    product_price,
    product_quantity,
    purchase_count,
    product_sale,
    classification_no)
values ('ASUS TUF B450-PRO GAMING STCOM',
    '메인보드 / 제조회사 : ASUS / CPU 소켓 : AMD(소켓AM4) / 세부 칩셋 : (AMD) B450 / 폼팩터 : ATX (30.5x24.4cm) / 메모리 종류 : DDR4 /',
    '175600',
    '999',
    '0',
    '0',
    '2');

insert into product (
    product_name,
    detail_description,
    product_price,
    product_quantity,
    purchase_count,
    product_sale,
    classification_no)
values ('MSI H310M PRO-VDH PLUS',
    '메인보드 / MSI H310M PRO-VDH PLUS',
    '73900',
    '999',
    '0',
    '0',
    '2');
    
insert into product (
    product_name,
    detail_description,
    product_price,
    product_quantity,
    purchase_count,
    product_sale,
    classification_no,
    seller_id)
values ('(ASUS) EX A320M-GAMING (iBORA)',
    '메인보드 / 제조회사 : ASUS / CPU 소켓 : AMD(소켓AM4) / 세부 칩셋 : (AMD) A320 / 폼팩터 : M-ATX (24.4x24.4cm) / 메모리 종류 : DDR4 / DVI : DVI / HDMI : HDMI / M.2 : 1개 / 메모리 슬롯 수 : 4개 /',
    '84600',
    '999',
    '0',
    '0',
    '2',
    'example_seller');